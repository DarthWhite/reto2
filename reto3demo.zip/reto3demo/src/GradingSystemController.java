import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class GradingSystemController extends SchoolGradingSystem{
    
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField txtEntryInt;

    @FXML
    private TextArea txtEntryFloat;

    @FXML
    private Button btnCalculate;

    @FXML
    private TextArea txtResult;

    @FXML
    void calculate(ActionEvent event) {


    }

    

    @FXML
    void initialize() {
        assert txtEntryInt != null : "fx:id=\"txtEntryInt\" was not injected: check your FXML file 'GradingSystemController.fxml'.";
        assert txtEntryFloat != null : "fx:id=\"txtEntryFloat\" was not injected: check your FXML file 'GradingSystemController.fxml'.";
        assert btnCalculate != null : "fx:id=\"btnCalculate\" was not injected: check your FXML file 'GradingSystemController.fxml'.";
        assert txtResult != null : "fx:id=\"txtResult\" was not injected: check your FXML file 'GradingSystemController.fxml'.";

    }
}
